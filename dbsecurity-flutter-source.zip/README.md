# Damascus Boulevard Security

## العميل الأساسي الحالي: Flutter

تمت إضافة العميل الجديد في `flutter_app/` ليكون صيغة التطبيق الأساسية للهاتف وFlutter Web. المجلدات القديمة الخاصة بـ Expo محفوظة مؤقتًا للرجوع والمقارنة، بينما الخادم وقاعدة البيانات في المشروع الأب مشتركان مع عميل Flutter.

تشغيل Flutter:

```bash
cd flutter_app
flutter pub get
flutter run -d chrome
```

راجع [دليل Flutter](flutter_app/README.md) للتفاصيل وحالة ربط API.

مشروع Expo Mobile / Expo Web لإدارة عمليات أمن Damascus Boulevard. المشروع يستخدم React Native وExpo Router وTypeScript وNativeWind، مع خادم Express/tRPC وقاعدة بيانات MySQL عبر Drizzle ORM.

> **حالة المشروع:** هذه النسخة هي vertical slice قابل للتشغيل. الواجهات الأساسية موجودة، بينما بعض وظائف الإنتاج مثل RBAC الكامل على الخادم، QR/GPS الفعلي، الإشعارات المجدولة، PDF، الذكاء الاصطناعي، والنسخ الاحتياطية ما زالت موثقة في `TODO.md` كمهام مفتوحة.

## التشغيل من VS Code

### المتطلبات

- Node.js 20 أو أحدث.
- pnpm 9.12 أو أحدث (`corepack enable` ثم `corepack prepare pnpm@9.12.0 --activate`).
- Docker Desktop، أو MySQL 8.0 متاح محليًا.
- Expo Go على الهاتف إذا أردت اختبار نسخة الهاتف؛ Expo Web يعمل من المتصفح.

### الإعداد الأولي

```bash
# 1) افتح المجلد في VS Code
code .

# 2) جهز البيئة
cp .env.example .env

# 3) شغل MySQL المحلي
 docker compose up -d mysql

# 4) ثبت الحزم
pnpm install

# 5) أنشئ/حدّث جداول قاعدة البيانات
pnpm db:push

# 6) حمّل بيانات التشغيل التجريبية إن احتجت
pnpm db:seed:ops
```

إذا كان لديك MySQL خارج Docker، عدّل `DATABASE_URL` في `.env` فقط، مثل:

```env
DATABASE_URL=mysql://USER:PASSWORD@127.0.0.1:3306/dbsecurity
```

### تشغيل التطبيق

```bash
# يشغل API على 3000 وExpo Web/Metro على 8081
pnpm dev
```

أو شغّل كل خدمة منفصلة:

```bash
pnpm dev:server   # http://localhost:3000
pnpm dev:metro    # http://localhost:8081
```

افتح `http://localhost:8081` للنسخة Web. لا تستخدم `CI=1` مع خدمة Metro المقيمة؛ هذا يعطل المراقبة وإعادة التحميل.

### الفحوصات

```bash
pnpm check       # TypeScript
pnpm test        # Vitest
pnpm lint        # Expo ESLint
pnpm format      # Prettier
```

## بنية المشروع

```text
app/                 شاشات Expo Router ومسارات التطبيق
  (tabs)/            الرئيسية، الحضور، الإشغال، الملاحظات، التقارير
components/          مكونات الواجهة المشتركة وQR وبطاقات العمليات
constants/           إعدادات OAuth والثوابت
hooks/               hooks للألوان وحالة النظام والمصادقة
drizzle/             schema.ts وملفات SQL وmetadata الخاصة بالـ migrations
lib/                 API client، التخزين المحلي، geofence، الثيم، Manus runtime
server/              Express/tRPC، المصادقة، قاعدة البيانات، التخزين، الخدمات
shared/              أنواع وبيانات مشتركة بين العميل والخادم
scripts/             تحميل البيئة، seed، وتوليد QR
tests/               اختبارات auth وCORS وgeofence
assets/images/       شعارات وأيقونات Expo
public/               manifest لمسارات Preview
plan.md              الخطة المعمارية والتصميمية
TODO.md              المتطلبات المتبقية وحالة التنفيذ
```

## قاعدة البيانات

قاعدة البيانات MySQL، وتُدار عبر Drizzle. المصدر الأساسي هو `drizzle/schema.ts`، والـ migrations الحالية موجودة في `drizzle/*.sql`.

الجداول الحالية:

- `users`: هوية المستخدم الأساسية ودور Manus.
- `security_profiles`: الرقم الوظيفي، PIN hash، الدور الأمني وحالة الحساب.
- `system_settings`: المنطقة الزمنية، geofence، مهلة الحضور والخروج والتذكير.
- `shifts`: تعريف الورديات وتداخلها.
- `attendance_sessions`: جلسات الحضور والانصراف وحالات الخروج التلقائي.
- `locations`: المطاعم والمحلات والمنشآت.
- `occupancy_readings`: قراءات الإشغال والاعتماد.
- `observations`: الملاحظات والحوادث والمخاطر والصيانة والمتابعة.
- `audit_log`: سجل تدقيق append-only مبدئي.

إعادة تطبيق المخطط على قاعدة محلية:

```bash
pnpm db:push
```

لا تضع بيانات الإنتاج داخل قاعدة Docker المحلية. قاعدة التطوير منفصلة، وعمليات الاختبار والـ seed تكتب بيانات فعلية في قاعدة التطوير المتصلة.

## الواجهات والوظائف الحالية

### واجهات التطبيق

- لوحة العمليات الرئيسية.
- الحضور والانصراف والوردية.
- الإشغال وقراءات المواقع واعتماد القراءة في الواجهة.
- الملاحظات والمتابعة وحالة claim.
- تقرير الوردية وتبديل العربية/English.
- واجهة OAuth callback.
- مختبر الثيم في `app/dev/theme-lab.tsx`.

### API الحالية

الخادم يستخدم tRPC تحت `/api/trpc`، والـ router الحالي في `server/routers.ts` يحتوي على:

- `auth.me`: قراءة المستخدم الحالي.
- `auth.logout`: إنهاء الجلسة.
- `system`: routers النظام الموروثة من القالب.

العمليات التشغيلية المعروضة حاليًا في الشاشات تحتاج استكمال ربطها بـ routers محمية في الخادم قبل اعتبارها جاهزة للإنتاج. لا تعتمد على حماية الواجهة وحدها.

## متغيرات البيئة

ابدأ من `.env.example` وانسخه إلى `.env`. أهم المتغيرات:

- `DATABASE_URL`: مطلوب لـ `pnpm db:push` وعمليات Drizzle.
- `PORT`: منفذ API، الافتراضي 3000.
- `EXPO_PUBLIC_API_BASE_URL`: عنوان API الذي يستخدمه العميل، محليًا `http://localhost:3000` للويب.
- `MANUS_PROJECT_ID`, `MANUS_JWT_SECRET`: هوية وجلسة الخادم.
- `MANUS_OAUTH_API_URL` أو `OAUTH_SERVER_URL`: خدمة OAuth.
- `MANUS_OAUTH_PORTAL_URL`: بوابة تسجيل الدخول.
- `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY`: تكاملات Manus الاختيارية.

لا تحفظ مفاتيح حقيقية في Git أو داخل `EXPO_PUBLIC_*` إلا إذا كانت قيمة عامة فعلًا؛ أي متغير يبدأ بـ `EXPO_PUBLIC_` قد يصل إلى حزمة العميل.

## ملاحظات الهاتف وExpo

- `pnpm dev:metro` يشغل Expo Web على 8081؛ الهاتف الفعلي يحتاج عنوان Metro يمكن الوصول إليه من الشبكة نفسها.
- الكاميرا، GPS، الإشعارات، الاهتزاز، deep links والتخزين الأصلي لا يثبتها اختبار Web وحده.
- مجلدات `ios/` و`android/` غير مولدة داخل المستودع؛ Dashboard/EAS أو `expo prebuild` هو مسار البناء الأصلي.
- لا توجد أسرار أو `node_modules` ضمن الحزمة المصدرية المسلّمة.

## تصدير المصدر

المصدر الكامل هو كل الملفات المتتبعة في هذا المجلد، بما فيها `app/`, `components/`, `server/`, `drizzle/`, `shared/`, `tests/`, `assets/`, وملفات الإعداد. استخدم:

```bash
pnpm install
pnpm check
pnpm test
```

ثم راجع `TODO.md` قبل بدء تطوير مرحلة الإنتاج.

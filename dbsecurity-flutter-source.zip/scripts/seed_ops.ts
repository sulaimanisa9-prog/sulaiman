import { eq } from "drizzle-orm";

import { locations, shifts, systemSettings } from "../drizzle/schema";
import { getDb } from "../server/db";
import { LOCATIONS, SHIFTS } from "../shared/mall";

async function seed() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL is required to seed operations data");

  try {
    for (const shift of SHIFTS) {
      const existing = await db.select({ id: shifts.id }).from(shifts).where(eq(shifts.code, shift.id)).limit(1);
      if (existing.length === 0) {
        await db.insert(shifts).values({ code: shift.id, labelAr: shift.label, labelEn: shift.labelEn, startTime: shift.time.slice(0, 5), endTime: shift.time.slice(-5), overlapMinutes: 30, active: true });
      }
    }

    for (const location of LOCATIONS) {
      const existing = await db.select({ id: locations.id }).from(locations).where(eq(locations.code, location.id)).limit(1);
      if (existing.length === 0) {
        await db.insert(locations).values({ code: location.id, nameAr: location.name, nameEn: location.nameEn, category: location.category === "مطعم" ? "restaurant" : "shop", floor: location.floor, active: true });
      }
    }

    const settings = await db.select({ id: systemSettings.id }).from(systemSettings).limit(1);
    if (settings.length === 0) {
      await db.insert(systemSettings).values({ timezone: "Asia/Damascus", geofenceMeters: 100, graceMinutes: 10, autoExitMinutes: 15, reminderMinutes: 5 });
    }

    console.log(`[seed] ${SHIFTS.length} shifts, ${LOCATIONS.length} locations and default settings are ready`);
  } finally {
    const client = (db as unknown as { $client?: { end?: () => Promise<void> } }).$client;
    await client?.end?.();
  }
}

seed().catch((error) => {
  console.error("[seed] failed", error);
  process.exitCode = 1;
});

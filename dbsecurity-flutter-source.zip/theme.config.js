/** @type {const} */
const themeColors = {
  primary: { light: '#A98D4F', dark: '#D5B96D' },
  background: { light: '#F8F7F3', dark: '#101820' },
  surface: { light: '#FFFFFF', dark: '#17232B' },
  foreground: { light: '#15232B', dark: '#F6F2E8' },
  muted: { light: '#68757B', dark: '#AAB6B8' },
  border: { light: '#E4E0D7', dark: '#31414A' },
  success: { light: '#16824B', dark: '#58C98B' },
  warning: { light: '#C77813', dark: '#E9B45A' },
  error: { light: '#B42318', dark: '#F28B82' },
};

module.exports = { themeColors };

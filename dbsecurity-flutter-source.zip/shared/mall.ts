export type ShiftStatus = "on-duty" | "handover" | "upcoming";
export type ObservationStatus = "قيد المعالجة" | "تم الحل" | "بانتظار المراجعة";

export type MallLocation = {
  id: string;
  name: string;
  nameEn: string;
  category: "مطعم" | "محل";
  floor: "الطابق الأرضي" | "الطابق الأول" | "الطابق الثاني" | "السطح";
  floorEn: string;
  occupancy: number;
  approved: boolean;
  lastRead: string;
};

export const SHIFTS = [
  { id: "morning", label: "الصباحية", labelEn: "Morning", time: "07:00 – 15:30", status: "on-duty" as ShiftStatus },
  { id: "evening", label: "المسائية", labelEn: "Evening", time: "15:00 – 23:30", status: "handover" as ShiftStatus },
  { id: "night", label: "الليلية", labelEn: "Night", time: "23:00 – 07:30", status: "upcoming" as ShiftStatus },
];

const locationRows: Array<[string, string, "مطعم" | "محل", MallLocation["floor"], string, number, boolean, string]> = [
  ["Askim", "Askim", "مطعم", "الطابق الأرضي", "Ground floor", 74, true, "10:00"],
  ["Del Sol", "Del Sol", "مطعم", "الطابق الأرضي", "Ground floor", 66, true, "10:00"],
  ["Cafe De Flour", "Cafe De Flour", "مطعم", "الطابق الأرضي", "Ground floor", 58, true, "10:00"],
  ["Black Out", "Black Out", "مطعم", "الطابق الأرضي", "Ground floor", 81, false, "10:00"],
  ["Angelina", "Angelina", "مطعم", "الطابق الأرضي", "Ground floor", 49, true, "10:00"],
  ["Velador", "Velador", "مطعم", "الطابق الأول", "First floor", 72, true, "10:00"],
  ["Chocolate Bar", "Chocolate Bar", "مطعم", "الطابق الأول", "First floor", 62, true, "10:00"],
  ["Baytoutoi", "Baytoutoi", "مطعم", "الطابق الأرضي", "Ground floor", 87, true, "10:00"],
  ["Cinder", "Cinder", "مطعم", "الطابق الثاني", "Second floor", 41, true, "10:00"],
  ["Maris", "Maris", "مطعم", "الطابق الأول", "First floor", 53, true, "10:00"],
  ["Nafas Roof", "Nafas Roof", "مطعم", "السطح", "Roof", 79, true, "10:00"],
  ["Roadhouse", "Roadhouse", "مطعم", "الطابق الأول", "First floor", 68, true, "10:00"],
  ["Yo80", "Yo80", "مطعم", "الطابق الأول", "First floor", 46, true, "10:00"],
  ["Aussie Roof", "Aussie Roof", "مطعم", "السطح", "Roof", 63, true, "10:00"],
  ["Aussie", "Aussie", "مطعم", "الطابق الثاني", "Second floor", 57, true, "10:00"],
  ["Nafas", "Nafas", "مطعم", "الطابق الثاني", "Second floor", 52, true, "10:00"],
  ["Velora Salon", "Velora Salon", "محل", "الطابق الأول", "First floor", 35, true, "10:00"],
  ["Al Rifai Roastery", "Al Rifai Roastery", "محل", "الطابق الأرضي", "Ground floor", 44, true, "10:00"],
  ["Boulevard Pharmacy", "Boulevard Pharmacy", "محل", "الطابق الأرضي", "Ground floor", 28, true, "10:00"],
  ["Tawfic Halak", "Tawfic Halak", "محل", "الطابق الأرضي", "Ground floor", 39, true, "10:00"],
  ["Bounce", "Bounce", "محل", "الطابق الأول", "First floor", 76, true, "10:00"],
  ["Smart Tech", "Smart Tech", "محل", "الطابق الأول", "First floor", 31, true, "10:00"],
];

export const LOCATIONS: MallLocation[] = locationRows.map(([id, name, category, floor, floorEn, occupancy, approved, lastRead]) => ({
  id,
  name,
  nameEn: name,
  category,
  floor,
  floorEn,
  occupancy,
  approved,
  lastRead,
}));

export const OBSERVATIONS = [
  { id: "OBS-1042", title: "باب طوارئ يحتاج إلى إبقاء الممر خاليًا", type: "ملاحظة سلامة", location: "الطابق الأول", status: "قيد المعالجة" as ObservationStatus, time: "09:42", owner: "أحمد خالد" },
  { id: "OBS-1041", title: "ملاحظة على منطقة تحميل المقاولين", type: "مقاولون", location: "الكراج", status: "بانتظار المراجعة" as ObservationStatus, time: "09:18", owner: "رامي حسن" },
  { id: "OBS-1039", title: "تمت معالجة تجمع زوار عند المدخل الرئيسي", type: "حادث أمني", location: "المدخل الرئيسي", status: "تم الحل" as ObservationStatus, time: "08:56", owner: "سليم درويش" },
];

export const STAFF = [
  { name: "أحمد خالد", role: "موظف أمن", status: "في الخدمة", checkIn: "07:04" },
  { name: "رامي حسن", role: "موظف كاميرات", status: "في الخدمة", checkIn: "06:58" },
  { name: "سليم درويش", role: "موظف أمن", status: "في الخدمة", checkIn: "07:11" },
  { name: "ليان مراد", role: "موظف أمن", status: "بانتظار الدخول", checkIn: "—" },
];

export const REPORT_SECTIONS = [
  { label: "الحالة العامة", state: "مكتمل" },
  { label: "حركة الزوار والإشغال", state: "تلقائي" },
  { label: "الحوادث والمخاطر", state: "مراجعة" },
  { label: "الأعطال وCCTV", state: "مفتوح" },
  { label: "الجولات وتسليم الوردية", state: "فارغ" },
];

export const OVERALL_OCCUPANCY = Math.round(
  LOCATIONS.filter((location) => location.approved).reduce((sum, location) => sum + location.occupancy, 0) /
    LOCATIONS.filter((location) => location.approved).length,
);

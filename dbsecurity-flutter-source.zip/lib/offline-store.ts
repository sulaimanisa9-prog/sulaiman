import AsyncStorage from "@react-native-async-storage/async-storage";

export type SyncState = "pending_sync" | "synced" | "conflict";

export type OfflineOperation = {
  id: string;
  type: "attendance" | "observation" | "occupancy" | "round";
  payload: Record<string, unknown>;
  createdAt: string;
  state: SyncState;
  attempts: number;
};

const OUTBOX_KEY = "dbsecurity.offline.outbox.v1";

async function readOutbox(): Promise<OfflineOperation[]> {
  const raw = await AsyncStorage.getItem(OUTBOX_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as OfflineOperation[];
  } catch {
    return [];
  }
}

export async function enqueueOfflineOperation(operation: Omit<OfflineOperation, "state" | "attempts">) {
  const outbox = await readOutbox();
  const next: OfflineOperation = { ...operation, state: "pending_sync", attempts: 0 };
  if (!outbox.some((item) => item.id === operation.id)) {
    outbox.push(next);
    await AsyncStorage.setItem(OUTBOX_KEY, JSON.stringify(outbox));
  }
  return next;
}

export async function listPendingOperations() {
  return (await readOutbox()).filter((item) => item.state === "pending_sync");
}

export async function markOperation(id: string, state: SyncState) {
  const outbox = await readOutbox();
  const next = outbox.map((item) => item.id === id ? { ...item, state, attempts: item.attempts + 1 } : item);
  await AsyncStorage.setItem(OUTBOX_KEY, JSON.stringify(next));
}

export async function clearSyncedOperations() {
  const outbox = await readOutbox();
  await AsyncStorage.setItem(OUTBOX_KEY, JSON.stringify(outbox.filter((item) => item.state !== "synced")));
}

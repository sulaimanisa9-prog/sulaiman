import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Text, View } from "react-native";

import { cn } from "@/lib/utils";

export function SectionHeading({ title, subtitle, action }: { title: string; subtitle?: string; action?: string }) {
  return (
    <View className="mb-3 flex-row-reverse items-end justify-between gap-3">
      <View className="flex-1 items-end">
        <Text className="text-lg font-bold text-foreground" style={{ textAlign: "right" }}>{title}</Text>
        {subtitle ? <Text className="mt-1 text-xs text-muted" style={{ textAlign: "right" }}>{subtitle}</Text> : null}
      </View>
      {action ? <Text className="text-xs font-semibold text-primary">{action}</Text> : null}
    </View>
  );
}

export function StatusPill({ label, tone = "neutral" }: { label: string; tone?: "success" | "warning" | "danger" | "neutral" | "info" }) {
  const styles = {
    success: "bg-success/15 text-success",
    warning: "bg-warning/15 text-warning",
    danger: "bg-error/15 text-error",
    info: "bg-primary/15 text-primary",
    neutral: "bg-muted/15 text-muted",
  }[tone];
  return <Text className={cn("rounded-full px-3 py-1 text-[11px] font-bold", styles)}>{label}</Text>;
}

export function MetricCard({ label, value, detail, icon, tone = "primary" }: { label: string; value: string; detail: string; icon: React.ComponentProps<typeof MaterialIcons>["name"]; tone?: "primary" | "success" | "warning" | "danger" }) {
  const iconColor = { primary: "#B39B63", success: "#15803D", warning: "#C77813", danger: "#B42318" }[tone];
  return (
    <View className="min-w-[150px] flex-1 rounded-3xl border border-border bg-surface p-4">
      <View className="flex-row-reverse items-center justify-between">
        <View className="h-10 w-10 items-center justify-center rounded-2xl bg-background">
          <MaterialIcons name={icon} size={20} color={iconColor} />
        </View>
        <Text className="text-xs font-semibold text-muted" style={{ textAlign: "right" }}>{label}</Text>
      </View>
      <Text className="mt-4 text-3xl font-bold text-foreground" style={{ textAlign: "right" }}>{value}</Text>
      <Text className="mt-1 text-xs text-muted" style={{ textAlign: "right" }}>{detail}</Text>
    </View>
  );
}

export function ProgressBar({ value, color = "#B39B63" }: { value: number; color?: string }) {
  return (
    <View className="h-2 overflow-hidden rounded-full bg-border">
      <View className="h-full rounded-full" style={{ width: `${Math.max(0, Math.min(100, value))}%`, backgroundColor: color }} />
    </View>
  );
}

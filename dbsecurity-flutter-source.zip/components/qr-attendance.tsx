import { CameraView, useCameraPermissions } from "expo-camera";
import * as Location from "expo-location";
import { useState } from "react";
import { Platform, Text, TouchableOpacity, View } from "react-native";

import { distanceInMeters } from "@/lib/geofence";

export type AttendanceScanResult = {
  method: "qr_geofence";
  qrValue: string;
  distanceMeters?: number;
  at: string;
};

type Props = {
  label: string;
  office?: { latitude: number; longitude: number };
  radiusMeters?: number;
  onComplete: (result: AttendanceScanResult) => void;
};

export function QrAttendance({ label, office, radiusMeters = 100, onComplete }: Props) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanning, setScanning] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("امسح رمز QR الموجود في مكتب الأمن");

  const startScan = async () => {
    if (Platform.OS === "web") {
      setStatus("المعاينة على الويب جاهزة؛ مسح الكاميرا يحتاج تطبيق الهاتف.");
      return;
    }
    const result = permission?.granted ? permission : await requestPermission();
    if (!result.granted) {
      setStatus("لم يتم السماح بالكاميرا. فعّل الإذن من إعدادات الهاتف.");
      return;
    }
    setStatus("وجّه الكاميرا نحو رمز QR");
    setScanning(true);
  };

  const handleBarcode = async ({ data }: { data: string }) => {
    if (busy) return;
    setBusy(true);
    setStatus("تمت قراءة QR؛ يجري التحقق من الموقع...");
    try {
      const locationPermission = await Location.requestForegroundPermissionsAsync();
      if (!locationPermission.granted) {
        setStatus("تمت قراءة QR، لكن يجب السماح بالموقع لإكمال الحضور.");
        return;
      }
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const distanceMeters = office ? distanceInMeters(office, current.coords) : undefined;
      if (distanceMeters !== undefined && distanceMeters > radiusMeters) {
        setStatus(`الموقع خارج النطاق (${Math.round(distanceMeters)}م). لم تثبت العملية.`);
        return;
      }
      onComplete({ method: "qr_geofence", qrValue: data, distanceMeters, at: new Date().toISOString() });
      setStatus("تم تثبيت الحضور بعد التحقق من QR والموقع.");
      setScanning(false);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View>
      {scanning ? (
        <View className="overflow-hidden rounded-3xl bg-black">
          <CameraView style={{ height: 220 }} facing="back" barcodeScannerSettings={{ barcodeTypes: ["qr"] }} onBarcodeScanned={busy ? undefined : handleBarcode} />
          <View className="absolute bottom-0 left-0 right-0 bg-black/70 px-4 py-3"><Text className="text-center text-xs font-bold text-white">{status}</Text></View>
        </View>
      ) : (
        <TouchableOpacity onPress={startScan} className="flex-row-reverse items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-4 active:opacity-75">
          <Text className="font-bold text-white">{label}</Text>
        </TouchableOpacity>
      )}
      {!scanning ? <Text className="mt-3 text-center text-xs text-muted">{status}</Text> : null}
    </View>
  );
}

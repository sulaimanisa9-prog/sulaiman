package com.damascus.boulevard.dbsecurity

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

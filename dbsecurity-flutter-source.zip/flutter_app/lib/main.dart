import 'package:flutter/material.dart';

import 'screens/attendance_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/observations_screen.dart';
import 'screens/occupancy_screen.dart';
import 'screens/reports_screen.dart';

ThemeData defaultAppTheme() => ThemeData(
      useMaterial3: true,
      fontFamily: 'Times New Roman',
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFB39B63), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF8F6EF),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8F6EF), foregroundColor: Color(0xFF101820), elevation: 0),
      cardTheme: CardThemeData(color: const Color(0xFFFFFEFA), margin: EdgeInsets.zero, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
    );

void main() => runApp(const DamascusSecurityApp());

class DamascusSecurityApp extends StatelessWidget {
  const DamascusSecurityApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner: false, title: 'Damascus Boulevard Security', theme: defaultAppTheme(), locale: const Locale('ar'), home: const AppShell());
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selectedIndex = 0;
  final pages = const [DashboardScreen(), AttendanceScreen(), OccupancyScreen(), ObservationsScreen(), ReportsScreen()];
  final labels = const ['الرئيسية', 'الحضور', 'الإشغال', 'الملاحظات', 'التقارير'];
  final icons = const [Icons.dashboard_outlined, Icons.badge_outlined, Icons.bar_chart_outlined, Icons.warning_amber_outlined, Icons.description_outlined];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth >= 900;
        return Scaffold(
          appBar: AppBar(title: Text(labels[selectedIndex], style: const TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_outlined)), const Padding(padding: EdgeInsetsDirectional.only(end: 18), child: CircleAvatar(child: Text('س')))]),
          body: Row(children: [
            if (wide) NavigationRail(selectedIndex: selectedIndex, onDestinationSelected: (value) => setState(() => selectedIndex = value), labelType: NavigationRailLabelType.all, leading: const Padding(padding: EdgeInsets.only(bottom: 24), child: Icon(Icons.shield_outlined, size: 32, color: Color(0xFFB39B63))), destinations: [for (var i = 0; i < labels.length; i++) NavigationRailDestination(icon: Icon(icons[i]), label: Text(labels[i]))]),
            Expanded(child: SafeArea(child: pages[selectedIndex])),
          ]),
          bottomNavigationBar: wide ? null : NavigationBar(selectedIndex: selectedIndex, onDestinationSelected: (value) => setState(() => selectedIndex = value), destinations: [for (var i = 0; i < labels.length; i++) NavigationDestination(icon: Icon(icons[i]), label: labels[i])]),
        );
      }),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {this.subtitle, super.key});
  final String title;
  final String? subtitle;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)), if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.black54))]]));
}

class MetricCard extends StatelessWidget {
  const MetricCard({required this.label, required this.value, required this.icon, super.key});
  final String label;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFFB39B63)), const SizedBox(height: 16), Text(value, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(label, style: const TextStyle(color: Colors.black54))])));
}

import 'package:flutter/material.dart';

import '../main.dart';

class OccupancyScreen extends StatelessWidget {
  const OccupancyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final locations = [('Askim', 'الطابق الأرضي', '82%'), ('Del Sol', 'الطابق الأول', '68%'), ('Nafas Roof', 'السطح', '74%'), ('Boulevard Pharmacy', 'الطابق الأرضي', '61%')];
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SectionTitle('قياسات الإشغال', subtitle: 'المجمع في لمحة · القراءة المعتمدة من المواقع فقط'),
        Card(
          color: const Color(0xFF101820),
          child: Padding(padding: const EdgeInsets.all(22), child: Row(children: const [
            Icon(Icons.bar_chart, color: Color(0xFFD5B96D), size: 42),
            SizedBox(width: 18),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('72%', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)), Text('المتوسط العام للمواقع المعتمدة', style: TextStyle(color: Colors.white70))]),
          ])),
        ),
        const SizedBox(height: 20),
        const SectionTitle('المواقع'),
        ...locations.map((location) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.storefront_outlined, color: Color(0xFFB39B63)),
                title: Text(location.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${location.$2} · آخر قراءة اليوم'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(location.$3, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(width: 12), OutlinedButton(onPressed: () {}, child: const Text('مراجعة'))]),
              ),
            )),
      ],
    );
  }
}

import 'package:flutter/material.dart';

import '../main.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool started = false;
  bool bilingual = true;

  @override
  Widget build(BuildContext context) {
    final sections = ['الحالة العامة', 'الحضور والإشغال', 'الحوادث والمخاطر', 'الجولات والكاميرات', 'الأعمال المعلقة', 'تسليم الوردية'];
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SectionTitle('تقارير الورديات', subtitle: 'البيانات التشغيلية تلقائية والحقول اليدوية جاهزة للمراجعة'),
        Card(
          color: const Color(0xFF101820),
          child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('تقرير الأربعاء · 18/11/2026', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            const Text('الوردية الصباحية', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            Text(started ? 'قيد التعبئة' : 'جاهز للبدء', style: const TextStyle(color: Color(0xFFD5B96D))),
          ])),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: FilledButton(onPressed: () => setState(() => started = true), child: Text(started ? 'التقرير مفتوح' : 'بدء تعبئة التقرير'))),
          const SizedBox(width: 12),
          OutlinedButton(onPressed: () => setState(() => bilingual = !bilingual), child: Text(bilingual ? 'عربي + English' : 'العربية فقط')),
        ]),
        const SizedBox(height: 18),
        ...sections.asMap().entries.map((entry) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(leading: CircleAvatar(child: Text('${entry.key + 1}')), title: Text(entry.value), subtitle: const Text('مملوء من سجلات النظام أو جاهز للإدخال اليدوي'), trailing: const Icon(Icons.chevron_left)),
            )),
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.picture_as_pdf_outlined), label: Text(bilingual ? 'تنزيل PDF عربي + English' : 'تنزيل PDF عربي')),
      ],
    );
  }
}

import 'package:flutter/material.dart';

import '../main.dart';

class ObservationsScreen extends StatefulWidget {
  const ObservationsScreen({super.key});

  @override
  State<ObservationsScreen> createState() => _ObservationsScreenState();
}

class _ObservationsScreenState extends State<ObservationsScreen> {
  final observations = <Map<String, String>>[
    {'id': 'OBS-104', 'title': 'ملاحظة سلامة عند المدخل الشمالي', 'type': 'سلامة', 'status': 'بانتظار المراجعة'},
    {'id': 'OBS-103', 'title': 'عطل في كاميرا الطابق الأول', 'type': 'كاميرات', 'status': 'قيد المتابعة'},
    {'id': 'OBS-102', 'title': 'تسليم وردية ومتابعة مقاول', 'type': 'مقاولون', 'status': 'تم الحل'},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SectionTitle('الملاحظات والمتابعة', subtitle: 'عين الفريق · الوصف والوقت والمنشئ تلقائيًا'),
        Align(alignment: AlignmentDirectional.centerStart, child: FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add_alert_outlined), label: const Text('إضافة ملاحظة'))),
        const SizedBox(height: 18),
        ...observations.map((item) => Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: const Icon(Icons.warning_amber_outlined, color: Color(0xFFB39B63)),
                title: Text(item['title']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${item['id']} · ${item['type']}'),
                trailing: OutlinedButton(onPressed: () => setState(() => item['status'] = item['status'] == 'قيد المتابعة' ? 'تم الحل' : 'قيد المتابعة'), child: Text(item['status']!)),
              ),
            )),
        Card(child: ListTile(leading: const Icon(Icons.sync), title: const Text('المزامنة دون إنترنت'), subtitle: const Text('تُحفظ العمليات محليًا وتُرفع عند عودة الاتصال مع منع التكرار.'))),
      ],
    );
  }
}

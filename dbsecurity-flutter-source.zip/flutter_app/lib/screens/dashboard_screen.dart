import 'package:flutter/material.dart';

import '../main.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final columns = MediaQuery.sizeOf(context).width >= 900 ? 4 : 2;
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SectionTitle('مركز العمليات', subtitle: 'ابدأ ورديتك بثقة · الأربعاء 18/11/2026'),
        Card(
          color: const Color(0xFF101820),
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Row(children: [
              const Icon(Icons.shield_outlined, size: 48, color: Color(0xFFD5B96D)),
              const SizedBox(width: 18),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  Text('الوردية الصباحية · في الخدمة', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('07:00 – 15:30 · المنطقة الزمنية: دمشق', style: TextStyle(color: Colors.white70)),
                ]),
              ),
              FilledButton(onPressed: () {}, child: const Text('عرض التفاصيل')),
            ]),
          ),
        ),
        const SizedBox(height: 20),
        GridView.count(
          crossAxisCount: columns,
          childAspectRatio: columns == 4 ? 1.75 : 1.45,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
          children: const [
            MetricCard(label: 'الحضور الحالي', value: '18 / 24', icon: Icons.groups_outlined),
            MetricCard(label: 'الإشغال المعتمد', value: '72%', icon: Icons.bar_chart_outlined),
            MetricCard(label: 'ملاحظات مفتوحة', value: '07', icon: Icons.warning_amber_outlined),
            MetricCard(label: 'بانتظار المراجعة', value: '03', icon: Icons.rate_review_outlined),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('إجراءات سريعة'),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            ActionButton(icon: Icons.qr_code_scanner, label: 'مسح QR للحضور', onPressed: () {}),
            ActionButton(icon: Icons.add_alert_outlined, label: 'إضافة ملاحظة', onPressed: () {}),
            ActionButton(icon: Icons.assessment_outlined, label: 'فتح تقرير الوردية', onPressed: () {}),
          ],
        ),
      ],
    );
  }
}

class ActionButton extends StatelessWidget {
  const ActionButton({required this.icon, required this.label, required this.onPressed, super.key});
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(onPressed: onPressed, icon: Icon(icon), label: Text(label));
  }
}

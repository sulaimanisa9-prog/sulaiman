import 'package:flutter/material.dart';

import '../main.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  bool checkedIn = false;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SectionTitle('الحضور والانصراف', subtitle: 'بوابة الوردية · التحقق عبر QR والموقع الجغرافي'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('الوردية الصباحية', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('07:00 – 15:30 · تداخل التسليم: 30 دقيقة'),
              const SizedBox(height: 20),
              LinearProgressIndicator(value: checkedIn ? .42 : .08, minHeight: 10, borderRadius: BorderRadius.circular(10)),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: () => setState(() => checkedIn = !checkedIn),
                icon: Icon(checkedIn ? Icons.logout : Icons.qr_code_scanner),
                label: Text(checkedIn ? 'تسجيل الخروج' : 'تسجيل الحضور عبر QR'),
              ),
              if (checkedIn) const Padding(padding: EdgeInsets.only(top: 12), child: Text('تم تثبيت الحضور محليًا · بانتظار المزامنة', style: TextStyle(color: Colors.green))),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle('تنبيهات المراجعة'),
        Card(
          child: ListTile(
            leading: const Icon(Icons.access_time, color: Colors.orange),
            title: const Text('خروج تلقائي · ليان مراد'),
            subtitle: const Text('تحتاج هذه العملية إلى مراجعة المشرف.'),
            trailing: FilledButton(onPressed: () {}, child: const Text('مراجعة')),
          ),
        ),
      ],
    );
  }
}

import 'package:flutter_test/flutter_test.dart';

import 'package:dbsecurity/main.dart';

void main() {
  testWidgets('renders the operations dashboard', (tester) async {
    await tester.pumpWidget(const DamascusSecurityApp());
    expect(find.text('مركز العمليات'), findsOneWidget);
    expect(find.text('الحضور الحالي'), findsOneWidget);
  });
}

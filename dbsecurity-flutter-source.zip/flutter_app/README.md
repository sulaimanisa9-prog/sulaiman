# Damascus Boulevard Security — Flutter client

هذا هو العميل الأساسي الجديد للهاتف والويب بعد تحويل واجهات Expo إلى Flutter. الخادم وقاعدة البيانات المشتركان بقيا في المجلد الأب: Express/tRPC وDrizzle/MySQL.

## المتطلبات

- Flutter 3.50 أو أحدث.
- Dart 3.14 أو أحدث.
- Android Studio + Android SDK لبناء Android.
- Xcode على macOS لبناء iOS.
- Chrome لبناء/تشغيل Flutter Web محليًا.
- VS Code مع Flutter وDart extensions.

## التشغيل

```bash
cd flutter_app
flutter pub get
flutter run -d chrome       # Flutter Web
flutter run                 # جهاز أو محاكي متاح
```

لبناء نسخة Web:

```bash
flutter build web
```

لتمرير عنوان API عند استكمال ربط الخادم:

```bash
flutter run -d chrome --dart-define=API_BASE_URL=http://localhost:3000
```

## الواجهات المنقولة

- لوحة العمليات الرئيسية.
- الحضور والانصراف والوردية.
- الإشغال وقراءات المواقع.
- الملاحظات والمتابعة وClaim/Solve.
- تقارير الوردية بالعربية/English.
- تنقل متجاوب: `NavigationBar` على الهاتف و`NavigationRail` على الشاشات الواسعة.
- RTL عربيًا افتراضيًا.
- Times New Roman كخط واجهة افتراضي مع fallback النظام.

## بنية Flutter

```text
lib/main.dart                         نقطة تشغيل التطبيق والثيم والتنقل
lib/screens/dashboard_screen.dart     لوحة العمليات
lib/screens/attendance_screen.dart    الحضور والانصراف
lib/screens/occupancy_screen.dart     الإشغال
lib/screens/observations_screen.dart  الملاحظات والمتابعة
lib/screens/reports_screen.dart       تقارير الورديات
test/widget_test.dart                 اختبار smoke للواجهة
assets/images/                        شعار وأيقونة المشروع
```

## التحقق

```bash
flutter analyze
flutter test
flutter build web
```

الحالة الحالية: التحليل بلا أخطاء، اختبار smoke ناجح، وبناء Web ناجح. وظائف API/المصادقة/قاعدة البيانات المعروضة في الواجهات تحتاج ربط إجراءات Flutter بخدمات tRPC المحمية في الخادم؛ الخادم الحالي يوفّر `auth.me` و`auth.logout` و`system`، بينما routers التشغيل التفصيلية ما زالت ضمن `TODO.md`.

لا تحذف مجلد الخادم أو `drizzle/`: Flutter هو عميل العرض والتفاعل، وليس بديلًا عن طبقة البيانات المركزية.

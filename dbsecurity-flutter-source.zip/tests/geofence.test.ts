import { describe, expect, it } from "vitest";

import { distanceInMeters } from "../lib/geofence";

describe("distanceInMeters", () => {
  it("returns zero for the same coordinate", () => {
    expect(distanceInMeters({ latitude: 33.5, longitude: 36.2 }, { latitude: 33.5, longitude: 36.2 })).toBe(0);
  });

  it("calculates a short walking-scale distance", () => {
    const distance = distanceInMeters({ latitude: 33.5, longitude: 36.2 }, { latitude: 33.5009, longitude: 36.2 });
    expect(distance).toBeGreaterThan(90);
    expect(distance).toBeLessThan(110);
  });
});

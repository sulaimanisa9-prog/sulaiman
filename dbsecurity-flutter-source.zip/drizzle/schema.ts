import { boolean, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const securityProfiles = mysqlTable("security_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  employeeNumber: varchar("employeeNumber", { length: 32 }).notNull().unique(),
  pinHash: varchar("pinHash", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  securityRole: mysqlEnum("securityRole", ["officer", "supervisor", "manager"]).notNull(),
  accountStatus: mysqlEnum("accountStatus", ["active", "suspended"]).default("active").notNull(),
  cameraDuty: boolean("cameraDuty").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const systemSettings = mysqlTable("system_settings", {
  id: int("id").autoincrement().primaryKey(),
  timezone: varchar("timezone", { length: 64 }).default("Asia/Damascus").notNull(),
  geofenceMeters: int("geofenceMeters").default(100).notNull(),
  graceMinutes: int("graceMinutes").default(10).notNull(),
  autoExitMinutes: int("autoExitMinutes").default(15).notNull(),
  reminderMinutes: int("reminderMinutes").default(5).notNull(),
  updatedBy: int("updatedBy"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const shifts = mysqlTable("shifts", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  labelAr: varchar("labelAr", { length: 64 }).notNull(),
  labelEn: varchar("labelEn", { length: 64 }).notNull(),
  startTime: varchar("startTime", { length: 5 }).notNull(),
  endTime: varchar("endTime", { length: 5 }).notNull(),
  overlapMinutes: int("overlapMinutes").default(30).notNull(),
  active: boolean("active").default(true).notNull(),
});

export const attendanceSessions = mysqlTable("attendance_sessions", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  shiftId: int("shiftId").notNull(),
  workDate: varchar("workDate", { length: 10 }).notNull(),
  status: mysqlEnum("status", ["scheduled", "checked_in", "checked_out", "auto_exit_pending", "auto_exit_approved", "auto_exit_rejected", "absent", "pending_verification"]).default("scheduled").notNull(),
  checkInAt: timestamp("checkInAt"),
  checkOutAt: timestamp("checkOutAt"),
  checkInMethod: mysqlEnum("checkInMethod", ["qr_geofence", "manual", "system"]),
  checkOutMethod: mysqlEnum("checkOutMethod", ["qr", "manual_supervisor", "system"]),
  autoExitNote: text("autoExitNote"),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const locations = mysqlTable("locations", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  nameAr: varchar("nameAr", { length: 128 }).notNull(),
  nameEn: varchar("nameEn", { length: 128 }).notNull(),
  category: mysqlEnum("category", ["restaurant", "shop", "facility"]).notNull(),
  floor: varchar("floor", { length: 64 }).notNull(),
  active: boolean("active").default(true).notNull(),
});

export const occupancyReadings = mysqlTable("occupancy_readings", {
  id: int("id").autoincrement().primaryKey(),
  locationId: int("locationId").notNull(),
  reportDate: varchar("reportDate", { length: 10 }).notNull(),
  readingSlot: varchar("readingSlot", { length: 5 }).notNull(),
  percentage: decimal("percentage", { precision: 5, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["submitted", "late", "approved", "rejected"]).default("submitted").notNull(),
  recordedBy: int("recordedBy").notNull(),
  approvedBy: int("approvedBy"),
  approvedAt: timestamp("approvedAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const observations = mysqlTable("observations", {
  id: int("id").autoincrement().primaryKey(),
  reference: varchar("reference", { length: 32 }).notNull().unique(),
  kind: mysqlEnum("kind", ["general", "incident", "hazard", "maintenance", "camera", "contractor", "event", "safety"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  locationId: int("locationId"),
  status: mysqlEnum("status", ["open", "claimed", "in_progress", "resolved", "pending_review"]).default("open").notNull(),
  severity: mysqlEnum("severity", ["low", "medium", "high"]),
  createdBy: int("createdBy").notNull(),
  claimedBy: int("claimedBy"),
  resolvedAt: timestamp("resolvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const auditLog = mysqlTable("audit_log", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").notNull(),
  action: varchar("action", { length: 64 }).notNull(),
  entityType: varchar("entityType", { length: 64 }).notNull(),
  entityId: varchar("entityId", { length: 64 }).notNull(),
  beforeHash: varchar("beforeHash", { length: 128 }),
  afterHash: varchar("afterHash", { length: 128 }).notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type SecurityProfile = typeof securityProfiles.$inferSelect;
export type OccupancyReading = typeof occupancyReadings.$inferSelect;
export type Observation = typeof observations.$inferSelect;

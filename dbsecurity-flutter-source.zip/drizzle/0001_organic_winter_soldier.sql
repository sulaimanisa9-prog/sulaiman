CREATE TABLE `attendance_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`shiftId` int NOT NULL,
	`workDate` varchar(10) NOT NULL,
	`status` enum('scheduled','checked_in','checked_out','auto_exit_pending','auto_exit_approved','auto_exit_rejected','absent','pending_verification') NOT NULL DEFAULT 'scheduled',
	`checkInAt` timestamp,
	`checkOutAt` timestamp,
	`checkInMethod` enum('qr_geofence','manual','system'),
	`checkOutMethod` enum('qr','manual_supervisor','system'),
	`autoExitNote` text,
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `attendance_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(64) NOT NULL,
	`entityType` varchar(64) NOT NULL,
	`entityId` varchar(64) NOT NULL,
	`beforeHash` varchar(128),
	`afterHash` varchar(128) NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `locations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`nameAr` varchar(128) NOT NULL,
	`nameEn` varchar(128) NOT NULL,
	`category` enum('restaurant','shop','facility') NOT NULL,
	`floor` varchar(64) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	CONSTRAINT `locations_id` PRIMARY KEY(`id`),
	CONSTRAINT `locations_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `observations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reference` varchar(32) NOT NULL,
	`kind` enum('general','incident','hazard','maintenance','camera','contractor','event','safety') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`locationId` int,
	`status` enum('open','claimed','in_progress','resolved','pending_review') NOT NULL DEFAULT 'open',
	`severity` enum('low','medium','high'),
	`createdBy` int NOT NULL,
	`claimedBy` int,
	`resolvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `observations_id` PRIMARY KEY(`id`),
	CONSTRAINT `observations_reference_unique` UNIQUE(`reference`)
);
--> statement-breakpoint
CREATE TABLE `occupancy_readings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`locationId` int NOT NULL,
	`reportDate` varchar(10) NOT NULL,
	`readingSlot` varchar(5) NOT NULL,
	`percentage` decimal(5,2) NOT NULL,
	`status` enum('submitted','late','approved','rejected') NOT NULL DEFAULT 'submitted',
	`recordedBy` int NOT NULL,
	`approvedBy` int,
	`approvedAt` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `occupancy_readings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `security_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`employeeNumber` varchar(32) NOT NULL,
	`pinHash` varchar(255) NOT NULL,
	`phone` varchar(32),
	`securityRole` enum('officer','supervisor','manager') NOT NULL,
	`accountStatus` enum('active','suspended') NOT NULL DEFAULT 'active',
	`cameraDuty` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `security_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `security_profiles_employeeNumber_unique` UNIQUE(`employeeNumber`)
);
--> statement-breakpoint
CREATE TABLE `shifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`labelAr` varchar(64) NOT NULL,
	`labelEn` varchar(64) NOT NULL,
	`startTime` varchar(5) NOT NULL,
	`endTime` varchar(5) NOT NULL,
	`overlapMinutes` int NOT NULL DEFAULT 30,
	`active` boolean NOT NULL DEFAULT true,
	CONSTRAINT `shifts_id` PRIMARY KEY(`id`),
	CONSTRAINT `shifts_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `system_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`timezone` varchar(64) NOT NULL DEFAULT 'Asia/Damascus',
	`geofenceMeters` int NOT NULL DEFAULT 100,
	`graceMinutes` int NOT NULL DEFAULT 10,
	`autoExitMinutes` int NOT NULL DEFAULT 15,
	`reminderMinutes` int NOT NULL DEFAULT 5,
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `system_settings_id` PRIMARY KEY(`id`)
);

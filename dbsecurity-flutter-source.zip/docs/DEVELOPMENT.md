# Developer Reference

## Source of truth

- Product and architecture decisions: `plan.md`
- Acceptance requirements and open work: `TODO.md`
- Database schema and types: `drizzle/schema.ts`
- SQL migration history: `drizzle/*.sql`
- tRPC router: `server/routers.ts`
- Client tRPC setup: `lib/trpc.ts`
- Environment loading: `scripts/load-env.js`

## Adding a database change

1. Edit `drizzle/schema.ts`.
2. Set `DATABASE_URL` to a local MySQL database.
3. Run `pnpm db:push`.
4. Inspect the generated SQL and metadata before committing.
5. Add/adjust server queries in `server/db.ts` or a feature module.
6. Add a protected tRPC procedure in `server/routers.ts`.
7. Add tests for authorization and state transitions.

## Adding a feature

Keep the layers separate:

- `app/`: screen and user interaction.
- `components/`: reusable presentation.
- `lib/`: client-side state, offline queue, geofence and API helpers.
- `server/`: validation, authorization, persistence and scheduled handlers.
- `shared/`: serializable types/constants shared by both sides.

Every mutation must validate the actor, role, current shift/state, allowed transition, and audit event on the server. A button being hidden in the UI is not an authorization boundary.

## Local ports

| Service | Port | Command |
|---|---:|---|
| Expo Web / Metro | 8081 | `pnpm dev:metro` |
| Express/tRPC API | 3000 | `pnpm dev:server` |
| MySQL | 3306 | `docker compose up -d mysql` |

## Current API boundary

The current `appRouter` exposes `auth.me`, `auth.logout`, and the template `system` router. The operational screen data is currently local/demo-oriented and should be moved behind typed, protected procedures as the remaining `TODO.md` items are implemented.

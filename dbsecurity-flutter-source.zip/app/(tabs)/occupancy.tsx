import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";

import { ProgressBar, SectionHeading, StatusPill } from "@/components/ops-ui";
import { ScreenContainer } from "@/components/screen-container";
import { LOCATIONS, OVERALL_OCCUPANCY } from "@/shared/mall";

export default function OccupancyScreen() {
  const [floor, setFloor] = useState<"الكل" | "الطابق الأرضي" | "الطابق الأول" | "الطابق الثاني" | "السطح">("الكل");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const filtered = useMemo(() => LOCATIONS.filter((location) => (floor === "الكل" || location.floor === floor) && location.name.toLowerCase().includes(search.toLowerCase())), [floor, search]);
  return (
    <ScreenContainer className="px-5 pb-6">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="mb-6 pt-3">
          <Text className="text-xs font-semibold text-primary" style={{ textAlign: "right" }}>قياسات الإشغال</Text>
          <View className="mt-2 flex-row-reverse items-end justify-between gap-3">
            <Text className="text-3xl font-bold text-foreground" style={{ textAlign: "right" }}>المجمع في لمحة</Text>
            <StatusPill label="10:00 معتمدة" tone="success" />
          </View>
          <Text className="mt-2 text-sm leading-6 text-muted" style={{ textAlign: "right" }}>تسع قراءات يومية، وتدخل 00:00 و02:00 ضمن يوم التقرير الذي يبدأ 07:00.</Text>
        </View>
        <View className="mb-6 rounded-[28px] bg-foreground p-5">
          <View className="flex-row-reverse items-center justify-between">
            <View className="items-end"><Text className="text-xs text-white/60">المتوسط العام للمواقع المعتمدة</Text><Text className="mt-1 text-4xl font-bold text-white">{OVERALL_OCCUPANCY}%</Text></View>
            <View className="h-16 w-16 items-center justify-center rounded-full border-[5px] border-primary"><MaterialIcons name="donut-large" size={28} color="#D5B96D" /></View>
          </View>
          <View className="mt-5"><ProgressBar value={OVERALL_OCCUPANCY} color="#D5B96D" /></View>
          <Text className="mt-3 text-xs text-white/65" style={{ textAlign: "right" }}>21 من 22 موقعًا لديها قراءة معتمدة · موقع واحد بانتظار المراجعة</Text>
        </View>
        <View className="mb-4 flex-row-reverse gap-2">
          <View className="flex-1 flex-row-reverse items-center rounded-2xl border border-border bg-surface px-3"><MaterialIcons name="search" size={18} color="#68757B" /><TextInput value={search} onChangeText={setSearch} placeholder="ابحث عن موقع" placeholderTextColor="#9AA4A6" className="flex-1 px-2 py-3 text-right text-sm text-foreground" /></View>
          <TouchableOpacity className="h-12 w-12 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add" size={22} color="#FFFFFF" /></TouchableOpacity>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingBottom: 16 }}>
          {["الكل", "الطابق الأرضي", "الطابق الأول", "الطابق الثاني", "السطح"].map((item) => <TouchableOpacity key={item} onPress={() => setFloor(item as typeof floor)} className={`rounded-full border px-4 py-2 ${floor === item ? "border-primary bg-primary" : "border-border bg-surface"}`}><Text className={`text-xs font-bold ${floor === item ? "text-white" : "text-muted"}`}>{item}</Text></TouchableOpacity>)}
        </ScrollView>
        <SectionHeading title="القراءات الحالية" subtitle={`${filtered.length} موقعًا · مراجعة المشرف قبل الاعتماد`} />
        {filtered.map((location) => (
          <View key={location.id} className="mb-3 rounded-2xl border border-border bg-surface p-4">
            <View className="flex-row-reverse items-center justify-between gap-3">
              <View className="flex-1 items-end"><Text className="text-sm font-bold text-foreground">{location.name}</Text><Text className="mt-1 text-xs text-muted">{location.category} · {location.floor} · آخر قراءة {location.lastRead}</Text></View>
              <Text className="text-2xl font-bold text-foreground">{location.occupancy}%</Text>
            </View>
            <View className="mt-3"><ProgressBar value={location.occupancy} color={location.occupancy >= 80 ? "#C77813" : "#A98D4F"} /></View>
            <View className="mt-3 flex-row-reverse items-center justify-between"><StatusPill label={location.approved ? "معتمدة" : "بانتظار المراجعة"} tone={location.approved ? "success" : "warning"} /><TouchableOpacity onPress={() => setEditing(editing === location.id ? null : location.id)}><Text className="text-xs font-bold text-primary">{editing === location.id ? "إخفاء" : "مراجعة القراءة"}</Text></TouchableOpacity></View>
            {editing === location.id ? <View className="mt-3 rounded-xl bg-background p-3"><Text className="text-xs leading-5 text-muted" style={{ textAlign: "right" }}>يظهر هنا سجل القراءات المتعددة للموقع، ويمكن للمشرف اختيار القراءة المناسبة واعتمادها أو تعديلها.</Text></View> : null}
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";

import { SectionHeading, StatusPill } from "@/components/ops-ui";
import { ScreenContainer } from "@/components/screen-container";
import { OBSERVATIONS, type ObservationStatus } from "@/shared/mall";

const filters: ("الكل" | ObservationStatus)[] = ["الكل", "قيد المعالجة", "بانتظار المراجعة", "تم الحل"];

export default function ObservationsScreen() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("الكل");
  const [claimed, setClaimed] = useState<string[]>([]);
  const filtered = useMemo(() => OBSERVATIONS.filter((item) => filter === "الكل" || item.status === filter), [filter]);
  return (
    <ScreenContainer className="px-5 pb-6">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="mb-6 pt-3">
          <View className="flex-row-reverse items-center justify-between"><View className="h-12 w-12 items-center justify-center rounded-2xl bg-primary"><MaterialIcons name="add-alert" size={24} color="#FFFFFF" /></View><View className="items-end"><Text className="text-xs font-semibold text-primary">الملاحظات والمتابعة</Text><Text className="mt-2 text-3xl font-bold text-foreground">عين الفريق</Text></View></View>
          <Text className="mt-3 text-sm leading-6 text-muted" style={{ textAlign: "right" }}>سجل الملاحظات، الحوادث، المخاطر والأعطال مع انتقال الحالات المفتوحة إلى الوردية التالية.</Text>
        </View>
        <View className="mb-5 rounded-3xl border border-border bg-surface p-4"><View className="flex-row-reverse items-center justify-between"><View className="flex-1 items-end"><Text className="text-sm font-bold text-foreground">إضافة ملاحظة ميدانية</Text><Text className="mt-1 text-xs text-muted" style={{ textAlign: "right" }}>الوصف والوقت والمنشئ تلقائيًا · الصورة اختيارية</Text></View><MaterialIcons name="photo-camera" size={22} color="#A98D4F" /></View><TouchableOpacity className="mt-4 rounded-2xl bg-foreground px-4 py-3"><Text className="text-center text-sm font-bold text-white">إنشاء ملاحظة</Text></TouchableOpacity></View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingBottom: 16 }}>{filters.map((item) => <TouchableOpacity key={item} onPress={() => setFilter(item)} className={`rounded-full border px-4 py-2 ${filter === item ? "border-primary bg-primary" : "border-border bg-surface"}`}><Text className={`text-xs font-bold ${filter === item ? "text-white" : "text-muted"}`}>{item}</Text></TouchableOpacity>)}</ScrollView>
        <SectionHeading title="المتابعة المفتوحة" subtitle={`${filtered.length} سجلات في الوردية الحالية`} />
        {filtered.map((item) => {
          const isClaimed = claimed.includes(item.id);
          return <View key={item.id} className="mb-4 rounded-3xl border border-border bg-surface p-4"><View className="flex-row-reverse items-start justify-between gap-3"><View className="flex-1 items-end"><View className="flex-row-reverse items-center gap-2"><Text className="text-[11px] font-bold text-primary">{item.id}</Text><Text className="text-[11px] text-muted">{item.time}</Text></View><Text className="mt-2 text-base font-bold text-foreground" style={{ textAlign: "right" }}>{item.title}</Text><Text className="mt-1 text-xs text-muted">{item.type} · {item.location} · {item.owner}</Text></View><StatusPill label={item.status} tone={item.status === "تم الحل" ? "success" : item.status === "بانتظار المراجعة" ? "warning" : "info"} /></View><View className="mt-4 flex-row-reverse items-center justify-between border-t border-border pt-3"><Text className="text-xs text-muted">{isClaimed ? "تم استلام المتابعة · أنت" : "لم يتم استلام المتابعة"}</Text>{item.status !== "تم الحل" ? <TouchableOpacity onPress={() => setClaimed((current) => isClaimed ? current.filter((id) => id !== item.id) : [...current, item.id])} className={`rounded-xl px-3 py-2 ${isClaimed ? "bg-success/15" : "bg-foreground"}`}><Text className={`text-xs font-bold ${isClaimed ? "text-success" : "text-white"}`}>{isClaimed ? "إلغاء الاستلام" : "استلام المتابعة"}</Text></TouchableOpacity> : <Text className="text-xs font-bold text-success">مغلقة</Text>}</View></View>;
        })}
        <View className="mt-2 rounded-3xl bg-background p-5"><View className="flex-row-reverse items-start gap-3"><MaterialIcons name="sync" size={21} color="#A98D4F" /><View className="flex-1 items-end"><Text className="text-sm font-bold text-foreground">المزامنة دون إنترنت</Text><Text className="mt-1 text-xs leading-5 text-muted" style={{ textAlign: "right" }}>تُحفظ الملاحظة محليًا وتُرفع تلقائيًا عند عودة الاتصال، مع منع التكرار عبر رقم العملية.</Text></View></View></View>
      </ScrollView>
    </ScreenContainer>
  );
}

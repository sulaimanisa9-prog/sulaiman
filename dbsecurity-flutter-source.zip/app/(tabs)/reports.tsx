import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";

import { SectionHeading, StatusPill } from "@/components/ops-ui";
import { ScreenContainer } from "@/components/screen-container";
import { REPORT_SECTIONS } from "@/shared/mall";

export default function ReportsScreen() {
  const [started, setStarted] = useState(false);
  const [language, setLanguage] = useState<"ar" | "both">("both");
  return (
    <ScreenContainer className="px-5 pb-6">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="mb-6 pt-3"><Text className="text-xs font-semibold text-primary" style={{ textAlign: "right" }}>تقارير الورديات</Text><Text className="mt-2 text-3xl font-bold text-foreground" style={{ textAlign: "right" }}>تقرير وردية واضح</Text><Text className="mt-2 text-sm leading-6 text-muted" style={{ textAlign: "right" }}>البيانات التشغيلية تلقائية، والحقول اليدوية جاهزة للمراجعة.</Text></View>
        <View className="mb-6 rounded-[28px] bg-foreground p-5"><View className="flex-row-reverse items-start justify-between gap-4"><View className="flex-1 items-end"><Text className="text-xs text-white/60">تقرير الأربعاء · 18/11/2026</Text><Text className="mt-2 text-xl font-bold text-white">الوردية الصباحية</Text><Text className="mt-1 text-xs text-white/65">07:00 – 15:30 · منشئ التقرير: مشرف القسم</Text></View><MaterialIcons name="description" size={30} color="#D5B96D" /></View><View className="mt-5 flex-row-reverse items-center justify-between border-t border-background/15 pt-4"><StatusPill label={started ? "قيد التعبئة" : "جاهز للبدء"} tone={started ? "warning" : "info"} /><Text className="text-xs text-white/65">الإغلاق بعد 10 دقائق من نهاية الوردية</Text></View></View>
        <View className="mb-6 flex-row-reverse gap-2"><TouchableOpacity onPress={() => setStarted(true)} className="flex-1 rounded-2xl bg-primary px-4 py-4"><Text className="text-center text-sm font-bold text-white">{started ? "التقرير مفتوح" : "بدء تعبئة التقرير"}</Text></TouchableOpacity><TouchableOpacity onPress={() => setLanguage(language === "both" ? "ar" : "both")} className="rounded-2xl border border-border bg-surface px-4 py-4"><Text className="text-center text-xs font-bold text-foreground">{language === "both" ? "عربي + English" : "العربية فقط"}</Text></TouchableOpacity></View>
        <SectionHeading title="أقسام التقرير" subtitle="قفل القسم يمنع التعديل المتزامن" />
        {REPORT_SECTIONS.map((section, index) => <View key={section.label} className="mb-3 flex-row-reverse items-center justify-between rounded-2xl border border-border bg-surface p-4"><View className="flex-row-reverse items-center gap-3"><View className="h-8 w-8 items-center justify-center rounded-full bg-background"><Text className="text-xs font-bold text-primary">{index + 1}</Text></View><View className="items-end"><Text className="text-sm font-bold text-foreground">{section.label}</Text><Text className="mt-1 text-xs text-muted">{section.state === "تلقائي" ? "مملوء من سجلات النظام" : section.state === "فارغ" ? "حقل يدوي" : "آخر تعديل منذ 4 دقائق"}</Text></View></View><StatusPill label={section.state} tone={section.state === "مكتمل" ? "success" : section.state === "مراجعة" ? "warning" : section.state === "مفتوح" ? "danger" : "neutral"} /></View>)}
        <View className="mt-3 rounded-3xl border border-primary/25 bg-primary/10 p-5"><View className="flex-row-reverse items-start gap-3"><MaterialIcons name="auto-awesome" size={22} color="#A98D4F" /><View className="flex-1 items-end"><Text className="text-sm font-bold text-foreground">اقتراح الملخص بالذكاء الاصطناعي</Text><Text className="mt-1 text-xs leading-5 text-muted" style={{ textAlign: "right" }}>سيجمع النظام الحضور، الإشغال، الحوادث والملاحظات في ملخص للمراجعة البشرية قبل الاعتماد.</Text><TouchableOpacity className="mt-3 rounded-xl bg-foreground px-4 py-2"><Text className="text-xs font-bold text-white">توليد اقتراح</Text></TouchableOpacity></View></View></View>
        <TouchableOpacity className="mt-5 flex-row-reverse items-center justify-center gap-2 rounded-2xl border border-border bg-surface px-4 py-4"><MaterialIcons name="picture-as-pdf" size={20} color="#B42318" /><Text className="text-sm font-bold text-foreground">تنزيل PDF عربي + English</Text></TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

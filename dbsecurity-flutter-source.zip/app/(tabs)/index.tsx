import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { useState } from "react";
import { Image, ScrollView, Text, TouchableOpacity, View } from "react-native";

import { MetricCard, ProgressBar, SectionHeading, StatusPill } from "@/components/ops-ui";
import { ScreenContainer } from "@/components/screen-container";
import { OBSERVATIONS, OVERALL_OCCUPANCY, SHIFTS, STAFF } from "@/shared/mall";

export default function OperationsDashboard() {
  const router = useRouter();
  const [acknowledged, setAcknowledged] = useState(false);
  const open = (path: "/attendance" | "/occupancy" | "/observations" | "/reports") => router.push(path);
  const activeStaff = STAFF.filter((person) => person.status === "في الخدمة").length;
  const openObservations = OBSERVATIONS.filter((item) => item.status !== "تم الحل").length;

  return (
    <ScreenContainer className="px-5 pb-6" safeAreaClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="mb-7 flex-row-reverse items-center justify-between gap-4 pt-3">
          <Image source={require("../../assets/images/brand-logo.png")} resizeMode="contain" className="h-12 w-48" />
          <View className="items-end">
            <Text className="text-xs font-semibold text-primary">مركز العمليات</Text>
            <Text className="mt-1 text-xs text-muted">18/11/2026 · 10:15</Text>
          </View>
        </View>

        <View className="mb-5 overflow-hidden rounded-[28px] bg-foreground p-5">
          <View className="flex-row-reverse items-start justify-between gap-4">
            <View className="flex-1 items-end">
              <View className="flex-row-reverse items-center gap-2">
                <View className="h-2.5 w-2.5 rounded-full bg-success" />
                <Text className="text-sm font-bold text-white">الوردية الصباحية · في الخدمة</Text>
              </View>
              <Text className="mt-3 text-2xl font-bold text-white" style={{ textAlign: "right" }}>
                صباح الخير، مشرف القسم
              </Text>
              <Text className="mt-2 text-sm leading-6 text-white/70" style={{ textAlign: "right" }}>
                كل المؤشرات الأساسية تحت المتابعة. يوجد {openObservations} بلاغات تحتاج إجراءً أو مراجعة.
              </Text>
            </View>
            <View className="h-14 w-14 items-center justify-center rounded-2xl bg-primary/20">
              <MaterialIcons name="shield" size={28} color="#D5B96D" />
            </View>
          </View>
          <View className="mt-5 flex-row-reverse items-center justify-between border-t border-background/15 pt-4">
            <Text className="text-xs text-white/70">التسليم القادم 15:00</Text>
            <Text className="text-xs font-bold text-primary">منطقة الزمن: دمشق</Text>
          </View>
        </View>

        <View className="mb-6 flex-row-reverse flex-wrap gap-3">
          <MetricCard label="في الخدمة" value={`${activeStaff}/15`} detail="أفراد مسجلون الآن" icon="groups" tone="success" />
          <MetricCard label="الإشغال العام" value={`${OVERALL_OCCUPANCY}%`} detail="21 قراءة معتمدة" icon="analytics" tone="primary" />
          <MetricCard label="الملاحظات المفتوحة" value={`${openObservations}`} detail="تحتاج متابعة" icon="notifications-active" tone="warning" />
          <MetricCard label="التقارير" value="1" detail="بانتظار اعتماد المشرف" icon="description" tone="danger" />
        </View>

        <SectionHeading title="إجراءات سريعة" subtitle="العمليات الأكثر استخدامًا أثناء الوردية" />
        <View className="mb-7 flex-row-reverse flex-wrap gap-3">
          {[
            { label: "الحضور والانصراف", detail: "QR + موقع", icon: "qr-code-scanner" as const, path: "/attendance" as const },
            { label: "قراءة إشغال", detail: "22 موقعًا", icon: "donut-large" as const, path: "/occupancy" as const },
            { label: "ملاحظة جديدة", detail: "حادث أو خطر", icon: "add-alert" as const, path: "/observations" as const },
            { label: "تقرير الوردية", detail: "PDF عربي/إنجليزي", icon: "picture-as-pdf" as const, path: "/reports" as const },
          ].map((action) => (
            <TouchableOpacity key={action.label} onPress={() => open(action.path)} className="min-w-[46%] flex-1 rounded-2xl border border-border bg-surface p-4 active:opacity-70">
              <View className="flex-row-reverse items-center justify-between">
                <View className="h-10 w-10 items-center justify-center rounded-xl bg-primary/15">
                  <MaterialIcons name={action.icon} size={20} color="#A98D4F" />
                </View>
                <MaterialIcons name="chevron-left" size={18} color="#68757B" />
              </View>
              <Text className="mt-4 text-sm font-bold text-foreground" style={{ textAlign: "right" }}>{action.label}</Text>
              <Text className="mt-1 text-xs text-muted" style={{ textAlign: "right" }}>{action.detail}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View className="mb-6 rounded-3xl border border-border bg-surface p-5">
          <SectionHeading title="الإشغال المباشر" subtitle="آخر قراءة معتمدة · 10:00" action="عرض التفاصيل" />
          <View className="mb-4 flex-row-reverse items-end justify-between">
            <View className="items-end">
              <Text className="text-4xl font-bold text-foreground">{OVERALL_OCCUPANCY}%</Text>
              <Text className="mt-1 text-xs text-success">+6% منذ 08:00</Text>
            </View>
            <View className="h-16 w-16 items-center justify-center rounded-full border-[6px] border-primary/20">
              <View className="h-11 w-11 items-center justify-center rounded-full bg-primary/10">
                <MaterialIcons name="people" size={22} color="#A98D4F" />
              </View>
            </View>
          </View>
          <ProgressBar value={OVERALL_OCCUPANCY} />
          <View className="mt-4 flex-row-reverse justify-between">
            {[
              { label: "الأرضي", value: 63 },
              { label: "الأول", value: 58 },
              { label: "الثاني", value: 49 },
              { label: "السطح", value: 71 },
            ].map((floor) => (
              <View key={floor.label} className="items-end">
                <Text className="text-xs text-muted">{floor.label}</Text>
                <Text className="mt-1 text-sm font-bold text-foreground">{floor.value}%</Text>
              </View>
            ))}
          </View>
        </View>

        <View className="mb-6 rounded-3xl border border-border bg-surface p-5">
          <SectionHeading title="الوردية وتسليم المتابعة" subtitle="التداخل الحالي 30 دقيقة" />
          {SHIFTS.map((shift) => (
            <View key={shift.id} className="mb-3 flex-row-reverse items-center justify-between rounded-2xl bg-background p-3">
              <View className="flex-1 items-end">
                <Text className="text-sm font-bold text-foreground">{shift.label} · {shift.time}</Text>
                <Text className="mt-1 text-xs text-muted">{shift.id === "morning" ? "المشرف: أنت · التقرير قيد الإنشاء" : "لا توجد ملاحظات استلام"}</Text>
              </View>
              <StatusPill label={shift.status === "on-duty" ? "جارية" : shift.status === "handover" ? "تسليم" : "قادمة"} tone={shift.status === "on-duty" ? "success" : shift.status === "handover" ? "warning" : "neutral"} />
            </View>
          ))}
        </View>

        <View className="rounded-3xl border border-warning/30 bg-warning/10 p-5">
          <View className="flex-row-reverse items-start gap-3">
            <MaterialIcons name="verified-user" size={22} color="#C77813" />
            <View className="flex-1 items-end">
              <Text className="text-sm font-bold text-foreground" style={{ textAlign: "right" }}>تنبيه يتطلب اطلاعك</Text>
              <Text className="mt-1 text-xs leading-5 text-muted" style={{ textAlign: "right" }}>
                توجد ملاحظة على منطقة تحميل المقاولين. راجعها أو عيّن موظفًا للمتابعة.
              </Text>
              <TouchableOpacity onPress={() => setAcknowledged(true)} className="mt-3 rounded-xl bg-foreground px-4 py-2 active:opacity-70">
                <Text className="text-xs font-bold text-white">{acknowledged ? "تم الاطلاع" : "تم الاطلاع"}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <Text className="mt-7 text-center text-[11px] text-muted">Damascus Boulevard Security · نموذج تشغيل أولي</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

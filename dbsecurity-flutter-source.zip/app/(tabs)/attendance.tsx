import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";

import { SectionHeading, StatusPill } from "@/components/ops-ui";
import { QrAttendance } from "@/components/qr-attendance";
import { ScreenContainer } from "@/components/screen-container";
import { STAFF } from "@/shared/mall";

export default function AttendanceScreen() {
  const [checkedIn, setCheckedIn] = useState(false);
  const [autoExitReviewed, setAutoExitReviewed] = useState(false);
  return (
    <ScreenContainer className="px-5 pb-6">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="mb-7 pt-3">
          <Text className="text-xs font-semibold text-primary" style={{ textAlign: "right" }}>الحضور والانصراف</Text>
          <Text className="mt-2 text-3xl font-bold text-foreground" style={{ textAlign: "right" }}>بوابة الوردية</Text>
          <Text className="mt-2 text-sm leading-6 text-muted" style={{ textAlign: "right" }}>تحقق من QR والموقع قبل تثبيت أي عملية حضور.</Text>
        </View>

        <View className="mb-6 rounded-[28px] bg-foreground p-5">
          <View className="flex-row-reverse items-center justify-between">
            <View className="items-end">
              <Text className="text-xs text-white/60">الوردية النشطة</Text>
              <Text className="mt-1 text-xl font-bold text-white">الصباحية · 07:00 – 15:30</Text>
            </View>
            <View className="h-12 w-12 items-center justify-center rounded-2xl bg-primary/20"><MaterialIcons name="schedule" size={24} color="#D5B96D" /></View>
          </View>
          <View className="mt-5 flex-row-reverse justify-between border-t border-background/15 pt-4">
            <Text className="text-xs text-white/70">فترة السماح: 10 دقائق</Text>
            <Text className="text-xs font-bold text-primary">تداخل التسليم: 30 د</Text>
          </View>
        </View>

        <View className="mb-6 rounded-3xl border border-border bg-surface p-5">
          <View className="flex-row-reverse items-start justify-between gap-4">
            <View className="flex-1 items-end">
              <Text className="text-lg font-bold text-foreground">تسجيل {checkedIn ? "الحضور مثبت" : "الحضور"}</Text>
              <Text className="mt-2 text-xs leading-5 text-muted" style={{ textAlign: "right" }}>
                امسح رمز QR الموجود في مكتب الأمن، ثم يؤكد التطبيق موقعك ضمن النطاق الذي حدده المشرف.
              </Text>
            </View>
            <View className="h-14 w-14 items-center justify-center rounded-2xl bg-primary/10"><MaterialIcons name={checkedIn ? "verified" : "qr-code-scanner"} size={28} color="#A98D4F" /></View>
          </View>
          <View className="mt-5">
            <QrAttendance label={checkedIn ? "مسح QR لتسجيل الخروج" : "بدء مسح QR"} onComplete={() => setCheckedIn((value) => !value)} />
          </View>
          <View className="mt-4 flex-row-reverse items-center justify-between">
            <Text className="text-xs text-muted">الموقع: مكتب الأمن · داخل النطاق</Text>
            <StatusPill label={checkedIn ? "مسجل 07:04" : "لم يسجل بعد"} tone={checkedIn ? "success" : "warning"} />
          </View>
        </View>

        <View className="mb-6 rounded-3xl border border-border bg-surface p-5">
          <SectionHeading title="حالات تحتاج اعتمادًا" subtitle="إجراءات المشرف" />
          <View className="rounded-2xl border border-warning/30 bg-warning/10 p-4">
            <View className="flex-row-reverse items-start justify-between gap-3">
              <View className="flex-1 items-end">
                <Text className="text-sm font-bold text-foreground">خروج تلقائي · ليان مراد</Text>
                <Text className="mt-1 text-xs leading-5 text-muted" style={{ textAlign: "right" }}>نهاية الوردية 23:30 · الخروج الآلي 23:45</Text>
              </View>
              <StatusPill label={autoExitReviewed ? "تمت المراجعة" : "بانتظارك"} tone={autoExitReviewed ? "success" : "warning"} />
            </View>
            <View className="mt-4 flex-row-reverse gap-2">
              <TouchableOpacity onPress={() => setAutoExitReviewed(true)} className="flex-1 rounded-xl bg-foreground px-3 py-3"><Text className="text-center text-xs font-bold text-white">اعتماد الخروج</Text></TouchableOpacity>
              <TouchableOpacity className="flex-1 rounded-xl border border-border px-3 py-3"><Text className="text-center text-xs font-bold text-foreground">رفض ومتابعة</Text></TouchableOpacity>
            </View>
          </View>
        </View>

        <SectionHeading title="سجل الموظفين" subtitle="الوردية الحالية · 15 فردًا" />
        {STAFF.map((person) => (
          <View key={person.name} className="mb-3 flex-row-reverse items-center justify-between rounded-2xl border border-border bg-surface p-4">
            <View className="flex-1 items-end">
              <Text className="text-sm font-bold text-foreground">{person.name}</Text>
              <Text className="mt-1 text-xs text-muted">{person.role} · دخول {person.checkIn}</Text>
            </View>
            <StatusPill label={person.status} tone={person.status === "في الخدمة" ? "success" : "warning"} />
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}
